{{- define "common.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "spark-app-base.configmap-code" -}}
{{- $releaseName := .Release.Name -}}
{{- $files := .files -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $releaseName }}-spark-code
  labels:
    subjectArea: {{ .Values.subjectArea }}
    {{- include "common.labels" . | nindent 4 }}
data:
  {{- range $key, $content := $files }}
  {{ $key }}: |-
    {{ $content | nindent 4 }}
  {{- end }}
{{- end -}}

{{- define "spark-app-base.configmap-requirements" -}}
{{- $releaseName := .Release.Name -}}
{{- $requirements := .requirements -}}
{{- $conda := .conda -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $releaseName }}-spark-deps
  labels:
    subjectArea: {{ .Values.subjectArea }}
    {{- include "common.labels" . | nindent 4 }}
data:
  requirements.txt: |-
    {{- $requirements | nindent 4 }}
  conda.yaml: |-
    {{- $conda | nindent 4 }}
{{- end -}}