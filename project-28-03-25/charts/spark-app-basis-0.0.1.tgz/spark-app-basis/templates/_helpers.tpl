{{- define "common.helm-labels" -}}
helm.sh/chart: {{ include "get-parent-chart-ref" . }}
app.kubernetes.io/version: {{ include "get-parent-app-version" . | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}

{{- define "get-parent-chart-ref" -}}
  {{- if .Values.global.parentChart -}}
    {{- printf "%s-%s" .Values.global.parentChart.name .Values.global.parentChart.version -}}
  {{- else -}}
    {{- printf "%s-%s" .Chart.Name .Chart.Version -}}
  {{- end -}}
{{- end -}}

{{- define "get-parent-app-version" -}}
  {{- if .Values.global.parentChart -}}
    {{- .Values.global.parentChart.appVersion -}}
  {{- else -}}
    {{- .Chart.AppVersion -}}
  {{- end -}}
{{- end -}}

{{- define "inject-helm-labels" -}}
{{- $labels := include "common.helm-labels" . | fromYaml }}
{{- toYaml $labels }}
{{- end -}}

{{- define "spark-app-base.configmap-code" -}}
{{- $releaseName := .Release.Name -}}
{{- $files := .files -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $releaseName }}-spark-code
  labels:
    subjectArea: {{ .Values.subjectArea }}
    {{- include "common.helm-labels" . | nindent 4 }}
data:
  {{- range $key, $content := $files }}
  {{ $key }}: |-
    {{ $content | nindent 4 }}
  {{- end }}
{{- end -}}

{{- define "spark-app-base.configmap-requirements" -}}
{{- $releaseName := .Release.Name -}}
{{- $requirements := .requirements -}}
{{- $conda := .conda -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $releaseName }}-spark-deps
  labels:
    subjectArea: {{ .Values.subjectArea }}
    {{- include "common.helm-labels" . | nindent 4 }}
data:
  requirements.txt: |-
    {{- $requirements | nindent 4 }}
  conda.yaml: |-
    {{- $conda | nindent 4 }}
{{- end -}}