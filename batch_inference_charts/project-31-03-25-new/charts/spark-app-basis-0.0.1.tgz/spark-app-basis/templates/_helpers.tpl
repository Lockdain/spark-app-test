{{- define "common.helm-labels" -}}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
app.kubernetes.io/revision: {{ .Release.Revision | quote }}
dognauts/subjectArea: {{ .Values.subjectArea }}
{{- end -}}

{{- define "inject-helm-labels" -}}
{{- $labels := include "common.helm-labels" . | fromYaml }}
{{- toYaml $labels }}
{{- end -}}

{{- define "spark-app-base.configmap-code" -}}
{{- $releaseName := .Release.Name -}}
{{- $files := .files -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $releaseName }}-spark-code
  labels:
    {{- include "common.helm-labels" . | nindent 4 }}
data:
  {{- range $key, $content := $files }}
  {{ $key }}: |-
    {{ $content | nindent 4 }}
  {{- end }}
{{- end -}}

{{- define "spark-app-base.configmap-requirements" -}}
{{- $releaseName := .Release.Name -}}
{{- $requirements := .requirements -}}
{{- $conda := .conda -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $releaseName }}-spark-deps
  labels:
    {{- include "common.helm-labels" . | nindent 4 }}
data:
  requirements.txt: |-
    {{- $requirements | nindent 4 }}
  conda.yaml: |-
    {{- $conda | nindent 4 }}
{{- end -}}