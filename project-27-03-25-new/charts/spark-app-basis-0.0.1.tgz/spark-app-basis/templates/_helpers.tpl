{{- define "spark-app-base.configmap-code" -}}
{{- $releaseName := .Release.Name -}}
{{- $files := .files -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $releaseName }}-spark-code
  labels:
    subjectArea: {{ .Values.subjectArea }}
data:
  _metadata: "{{ $releaseName }}"
  {{- range $key, $content := $files }}
  {{ $key }}: |-
    {{ $content | nindent 4 }}
  {{- end }}
{{- end -}}

{{- define "spark-app-base.configmap-requirements" -}}
{{- $releaseName := .Release.Name -}}
{{- $requirements := .requirements -}}
{{- $conda := .conda -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $releaseName }}-spark-deps
  labels:
    subjectArea: {{ .Values.subjectArea }}
data:
  requirements.txt: |-
    {{- $requirements | nindent 4 }}
  conda.yaml: |-
    {{- $conda | nindent 4 }}
{{- end -}}